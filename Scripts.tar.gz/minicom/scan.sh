ls /dev/tty*
