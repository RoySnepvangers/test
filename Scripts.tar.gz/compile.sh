export PICO_SDK_PATH=~/pico-sdk
cd build
cmake ..
make -j4
echo 'Klaar met compilen!'
